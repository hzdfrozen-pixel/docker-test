# 研究生分布式系统实验

### SDCS: Simple Distributed Cache System

简易分布式缓存系统

```shell
# Use docker compose to start quickly.
docker-compose up --build
```